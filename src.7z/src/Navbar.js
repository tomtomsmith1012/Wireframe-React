import React, { Component } from 'react';
import './App.css';
import {
    BrowserRouter as Router,
    Route,
    Link
} from 'react-router-dom'
import App from './App.js';

class Navbar extends Component {
    constructor() {
      super();
      }
  
    render() {
      return(
        <Router>
            <div>
                <ul class="navbar">
                    <li class="nav"><Link to = "/timetable">Timetable</Link></li>
                    <li class="nav"><Link to = "/adjustTimetable">Adjust Timetable</Link></li>
                    <li class><Link to = "/profile">Profile</Link></li>
                </ul>
                <Route path="/timetable" component={App}></Route>
                <Route path="/adjustTimetable" component={App}></Route>
                <Route path="/profile" component={App}></Route>
            </div>  
        </Router>
      );
    }
  }

export default Navbar;