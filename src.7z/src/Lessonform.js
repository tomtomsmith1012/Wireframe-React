import React, { Component } from 'react';
import './App.css';
import Lessonbuttons from './Lessonbuttons.js'

class Lessonform extends Component {
    constructor() {
      super();
      }
  
    render() {
      return(
        <div>
            <table class="lessons">
                <tr class="tablehead">
                    <th class="thead">Morning / 9:00</th>
                    <th class="thead">Afternoon / 12:00</th>
                    <th class="thead">Evening / 3:00</th>
                </tr>
                <tr class="tabledata">
                    <div class="table">
                    <td class="tdata"></td>
                    </div>
                    <td class="tdata">Sample Lesson</td>
                    <td class="tdata">Sample Lesson</td>
                </tr>
            </table>
        </div>
      );
    }
  }

export default Lessonform;