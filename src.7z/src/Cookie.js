import React, { Component } from 'react';
import './App.css';

class Cookie extends Component {
    render() {
        return (
            <div>
            <img onClick={this.stateChange.bind(this)} src="https://www.otisspunkmeyer.com/sites/default/files/styles/large/public/products/OS-Fundraising-ChocolateChipTop_whitespace.png?itok=BKw4fYJ7" width={200} 
      height={125}></img>
          </div>
        );
    }
}

export default Cookie;