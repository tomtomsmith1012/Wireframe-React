import React, { Component } from 'react';
import './App.css';

class Powerup extends Component {
    render() {
        return (
            <div>
            <button type="button" onClick={this.powerUp.bind(this)}>{this.cost}</button>
          </div>
        );
    }
}

export default Powerup;