import React, { Component } from 'react';
import './App.css';
import App from './App.js';

class Calendar extends Component {
    constructor() {
      super();
      this.state = {
          x: 1
      }
      }
  
    render() {
      return(
        <div>
        <div class="month"> 
                <ul>
                <li> February 2019
                </li>
                </ul>
        </div>
      
      
            <ul class="weekdays">
                <li>Mo</li>
                <li>Tu</li>
                <li>We</li>
                <li>Th</li>
                <li>Fr</li>
                <li>Sa</li>
                <li>Su</li>
            </ul>
      
            <ul class="days"> 
                <li color="#777777"><span onClick={this.activate.bind(this)}>28</span></li>
                <li color="#777777"><span onClick={this.activate.bind(this)}>29</span></li>
                <li color="#777777"><span onClick={this.activate.bind(this)}>30</span></li>
                <li color="#777777"><span onClick={this.activate.bind(this)}>31</span></li>
                <li><span onClick={this.activate.bind(this)}>1</span></li>
                <li><span onClick={this.activate.bind(this)}>2</span></li>
                <li><span onClick={this.activate.bind(this)}>3</span></li>
                <li><span onClick={this.activate.bind(this)}>4</span></li>
                <li><span onClick={this.activate.bind(this)}>5</span></li>
                <li><span onClick={this.activate.bind(this)}>6</span></li>
                <li><span onClick={this.activate.bind(this)}>7</span></li>
                <li><span onClick={this.activate.bind(this)}>8</span></li>
                <li><span onClick={this.activate.bind(this)}>9</span></li>
                <li><span onClick={this.activate.bind(this)}>10</span></li>
                <li><span onClick={this.activate.bind(this)}>11</span></li>
                <li><span onClick={this.activate.bind(this)}>12</span></li>
                <li><span onClick={this.activate.bind(this)}>13</span></li>
                <li><span onClick={this.activate.bind(this)}>14</span></li>
                <li><span onClick={this.activate.bind(this)}>15</span></li>
                <li><span onClick={this.activate.bind(this)}>16</span></li>
                <li><span onClick={this.activate.bind(this)}>17</span></li>
                <li><span onClick={this.activate.bind(this)}>18</span></li>
                <li><span onClick={this.activate.bind(this)}>19</span></li>
                <li><span onClick={this.activate.bind(this)}>20</span></li>
                <li><span onClick={this.activate.bind(this)}>21</span></li>
                <li><span onClick={this.activate.bind(this)}>22</span></li>
                <li><span onClick={this.activate.bind(this)}>23</span></li>
                <li><span onClick={this.activate.bind(this)}>24</span></li>
                <li><span onClick={this.activate.bind(this)}>25</span></li>
                <li><span onClick={this.activate.bind(this)}>26</span></li>
                <li><span onClick={this.activate.bind(this)}>27</span></li>
                <li><span onClick={this.activate.bind(this)}>28</span></li>
            </ul>
        </div>
      );
    }

    activate(e) {
        this.setState({
          x:1
        });
        e.target.className = "active";
    }

    colorful(e) {
        e.target.background = "red";
    }
  }

export default Calendar;