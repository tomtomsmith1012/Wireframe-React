import React, { Component } from 'react';
import './App.css';
import Navbar from './Navbar.js'
import Calendar from './Calendar.js'
import Lessonbuttons from './Lessonbuttons.js'

class App extends Component {
  constructor() {
    super();
    this.state = {
      lesson: "Click to Begin",
      }
    }

  render() {
    return(
    <div>
        <div class="top">
            <img class="logo" src="./img/logo.png" alt = "trainer logo"></img>
            <a class="login" href = "./App.js">Login</a>
        </div>
        <div class ="searchbar">
            <input class="search" type="text" placeholder="Search..."></input>
        </div>
        <div class="navbar">
            <Navbar></Navbar>
        </div>
        <div class="calendar">
            <Calendar></Calendar>
        </div>
        <div>
            <Lessonbuttons></Lessonbuttons>
        </div>
    </div>
    );
  }
}


export default App;
