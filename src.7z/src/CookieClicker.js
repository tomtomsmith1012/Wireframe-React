import React, { Component } from 'react';
import './App.css';
import Header from './Header.js';

class App extends Component {
  constructor() {
    super();
    this.value = 1;
    this.increment = 1;
    this.cost1 = 50;
    this.cost2 = 100;
    this.cost3 = 1000;
    this.cost4 = 5000;
    this.cost5 = 10000;
    this.costx2 = 50000;
    this.costx5 = 250000;
    this.costx10 = 1000000;
    this.costx25 = 1000000000;
    this.costx100 = 9999999999999;
    this.Stylea1 = {background: "grey"};
    this.Stylea2 = null;
    this.Stylea3 = null;
    this.Stylea4 = null;
    this.Stylea5 = null;
    this.Stylex2 = null;
    this.Stylex5 = null;
    this.Stylex10 = null;
    this.Stylex25 = null;
    this.Stylex100 = null;
    this.factor = 1.1;
    this.state = {
      header: "Click to Begin",

    }
  }


  render() {

    if(this.value > this.cost1) {
      this.Stylea1 = {background: "#00cc00"};
    }else {  this.Stylea1 = {background: "#cccccc"};}

    if(this.value > this.cost2) {
      this.Stylea2 = {background: "#00cc00"};
    }else {  this.Stylea2 = {background: "#cccccc"};}

    if(this.value > this.cost3) {
      this.Stylea3 = {background: "#00cc00"};
    }else {  this.Stylea3 = {background: "#cccccc"};}

    if(this.value > this.cost4) {
      this.Stylea4 = {background: "#00cc00"};
    }else {  this.Stylea4 = {background: "#cccccc"};}

    if(this.value > this.cost5) {
      this.Stylea5 = {background: "#00cc00"};
    }else {  this.Stylea5 = {background: "#cccccc"};}

    if(this.value > this.costx2) {
      this.Stylex2 = {background: "#00cc00"};
    }else {  this.Stylex2 = {background: "#cccccc"};}

    if(this.value > this.costx5) {
      this.Stylex5 = {background: "#00cc00"};
    }else {  this.Stylex5 = {background: "#cccccc"};}

    if(this.value > this.costx10) {
      this.Stylex10 = {background: "#00cc00"};
    }else {  this.Stylex10 = {background: "#cccccc"};}

    if(this.value > this.costx25) {
      this.Stylex25 = {background: "#00cc00"};
    }else {  this.Stylex25 = {background: "#cccccc"};}

    if(this.value > this.costx100) {
      this.Stylex100 = {background: "#00cc00"};
    }else {  this.Stylex100 = {background: "#cccccc"};}


    return(
    <div>
      <Header headerProp = {this.state.header}/>
      <img cookie onClick={this.stateChange.bind(this)} src="https://www.otisspunkmeyer.com/sites/default/files/styles/large/public/products/OS-Fundraising-ChocolateChipTop_whitespace.png?itok=BKw4fYJ7" width={200} 
      height={125}></img>
      <div>
        <button type="button" style ={this.Stylea1} onClick={this.powerUp1.bind(this)}>{this.cost1}, +1 boost</button>
        <button type="button" style ={this.Stylea2} onClick={this.powerUp2.bind(this)}>{this.cost2}, +2 boost</button>
        <button type="button" style ={this.Stylea3} onClick={this.powerUp3.bind(this)}>{this.cost3}, +3 boost</button>
        <button type="button" style ={this.Stylea4} onClick={this.powerUp4.bind(this)}>{this.cost4}, +4 boost</button>
        <button type="button" style ={this.Stylea5} onClick={this.powerUp5.bind(this)}>{this.cost5}, +5 boost</button>
      </div>
      <div>
        <button type="button" style ={this.Stylex2} onClick={this.powerUpx2.bind(this)}>{this.costx2}, x2 boost</button>
        <button type="button" style ={this.Stylex5} onClick={this.powerUpx5.bind(this)}>{this.costx5}, x5 boost</button>
        <button type="button" style ={this.Stylex10} onClick={this.powerUpx10.bind(this)}>{this.costx10}, x10 boost</button>
        <button type="button" style ={this.Stylex25} onClick={this.powerUpx25.bind(this)}>{this.costx25}, x25 boost</button>
      </div>
      <div>
        <button type="button" style ={this.Stylex100} onClick={this.powerUpx100.bind(this)}>{this.costx100}, x100 boost</button>
      </div>
    </div>

    );
  }

  stateChange() {
    this.setState({
      header: this.value + " +" + this.increment
    })
    this.value+=this.increment;
  }

  powerUp1() {

    if (this.value > this.cost1) {
      this.value -= this.cost1;
      this.setState({
        header: this.value + " +" + this.increment
      })
    this.increment+=1;
    this.cost1 = Math.round(Math.pow(this.cost1, this.factor));
    }
  }

  powerUp2() {

    if (this.value > this.cost2) {
      this.value -= this.cost2;
      this.setState({
        header: this.value + " +" + this.increment
      })
    this.increment+=2;
    this.cost2 = Math.round(Math.pow(this.cost2, this.factor));
    }
  }

  
  powerUp3() {

    if (this.value > this.cost3) {
      this.value -= this.cost3;
      this.setState({
        header: this.value + " +" + this.increment
      })
    this.increment+=3;
    this.cost3 = Math.round(Math.pow(this.cost3, this.factor));
    }
  }

  powerUp4() {

    if (this.value > this.cost4) {
      this.value -= this.cost4;
      this.setState({
        header: this.value + " +" + this.increment
      })
    this.increment+=4;
    this.cost4 = Math.round(Math.pow(this.cost4, this.factor));
    }
  }

  powerUp5() {

    if (this.value > this.cost5) {
      this.value -= this.cost5;
      this.setState({
        header: this.value + " +" + this.increment
      })
    this.increment+=5;
    this.cost5 = Math.round(Math.pow(this.cost5, this.factor));
    }
  }

  
  powerUpx2() {

    if (this.value > this.costx2) {
      this.value -= this.costx2;
      this.setState({
        header: this.value + " +" + this.increment
      })
    this.increment*=2;
    this.costx2 = Math.round(Math.pow(this.costx2, this.factor));
    }
  }

  powerUpx5() {

    if (this.value > this.costx5) {
      this.value -= this.costx5;
      this.setState({
        header: this.value + " +" + this.increment
      })
    this.increment*=5;
    this.costx5 = Math.round(Math.pow(this.costx10, this.factor));
    }
  }

  powerUpx10() {

    if (this.value > this.costx10) {
      this.value -= this.costx10;
      this.setState({
        header: this.value + " +" + this.increment
      })
    this.increment*=10;
    this.costx10 = Math.round(Math.pow(this.costx10, this.factor));
    }
  }
  
  powerUpx25() {

    if (this.value > this.costx25) {
      this.value -= this.costx25;
      this.setState({
        header: this.value + " +" + this.increment
      })
    this.increment*=25;
    this.costx25 = Math.round(Math.pow(this.costx25, this.factor));
    }
  }

  powerUpx100() {

    if (this.value > this.costx100) {
      this.value -= this.costx100;
      this.setState({
        header: this.value + " +" + this.increment
      })
    this.increment*=100;
    this.costx100 = Math.round(Math.pow(this.costx100, this.factor));
    }
  }
}

export default App;
