import React, { Component } from 'react';
import './App.css';

class Lessonbuttons extends Component {
    constructor() {
      super();
      this.state = {
        inputValue1: "Edit Lesson 1",
        inputValue2: "Edit Lesson 2",
        inputValue3: "Edit Lesson 3"
      }
      }
  
    render() {
      return(
        <div>
            <div class="lesson">
                <input value={this.state.inputValue1} onChange={this.updateInputValue1.bind(this)} class="lesson1" type="text"></input>
                <input value={this.state.inputValue2} onChange={this.updateInputValue2.bind(this)} class="lesson2" type="text"></input>
                <input value={this.state.inputValue3} onChange={this.updateInputValue3.bind(this)} class="lesson3" type="text"></input>
            </div>
            <div>
            <table class="lessons">
                <tr class="tablehead">
                    <th class="thead">Morning / 9:00</th>
                    <th class="thead">Afternoon / 12:00</th>
                    <th class="thead">Evening / 3:00</th>
                </tr>
                <tr class="tabledata">
                    <td class="tdata">{this.state.inputValue1}</td>
                    <td class="tdata">{this.state.inputValue2}</td>
                    <td class="tdata">{this.state.inputValue3}</td>
                </tr>
            </table>
            </div>
        </div>
      );
    }


    updateInputValue1(e) {
        this.setState({
            inputValue1: e.target.value
        })
    }

    updateInputValue2(e) {
        this.setState({
            inputValue2: e.target.value
        })
    }

    updateInputValue3(e) {
        this.setState({
            inputValue3: e.target.value
        })
    }
  }

export default Lessonbuttons;