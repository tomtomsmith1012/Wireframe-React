import React, { Component } from 'react';
import './App.css';

class Content extends Component {
    render() {
        return (
            <div>
            <p>
                {this.props.contentProp}
            </p>
          </div>
        );
    }
}

export default Content;